from replit import clear
from art import logo, vs
from game_data import data
import random

# Function to return winner
def winner(compA, compB):
  if compA['follower_count'] > compB['follower_count']:
    return 'a'
  return 'b'

# Function to print comparison
def printComp(compA, compB, score):
  # Clear screen and Print logo
  clear()
  print(logo)
  if score:
    print(f"You're right! Current score: {score}.")

  print(f"Compare A: {compA['name']}, a/an {compA['description']}, from {compA['country']}.")

  # print vs
  print(vs)

  # Select random index from data list => Against B (except A)
  print(f"Against B: {compB['name']}, a/an {compB['description']}, from {compB['country']}.")

# Score
score = 0

# Select random index from data list => Compare A
compA = random.choice(data)


# Select random index from data list => Against B (except A)
compB = random.choice([x for x in data if x != compA])

# Call printComp
printComp(compA, compB, score)

# Ask question Who has more followers? Type 'A' or 'B':
answer = input("Who has more followers? Type 'A' or 'B':\n").lower()


# If correct keep calculating score and Compare A becomes B
while answer == winner(compA, compB):
  score += 1
  compA = compB

  # Select random index from data list => Against B (except A)
  compB = random.choice([x for x in data if x != compA])
  printComp(compA, compB, score)

  # Ask question Who has more followers? Type 'A' or 'B':
  answer = input("Who has more followers? Type 'A' or 'B':\n").lower()

# If incorrect exit the program 
print(f"Sorry! that's wrong. Final score: {score}")



