from art import logo

alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

def caesar(caesar_text, shift_amount, en_de_direction):
  result_text = ""
  # When decoding shift letters toward left
  if en_de_direction == "decode":
    shift_amount *= -1
  for char in caesar_text:
    if char not in alphabet:
      continue
    position = alphabet.index(char)
    new_position = position + shift_amount
    new_position %= 26
    result_text += alphabet[new_position]
  print(f"The {en_de_direction}d text is: {result_text}")

# Import and print the logo from art.py when the program starts.
print(logo)

# Ask user to continue and run program repeatedly?
to_continue = True 
while to_continue:
  direction = input("Type 'encode' to encrypt, type 'decode' to decrypt:\n")
  text = input("Type your message:\n").lower()
  shift = int(input("Type the shift number:\n"))
  caesar(caesar_text = text, shift_amount = shift, en_de_direction = direction)
  want_continue = input("Type 'yes' if you want to go again. Otherwise type 'no'.\n")
  if want_continue == "no":
    to_continue = False
    print("Goodbye!")