from replit import clear
from art import logo
#HINT: You can call clear() to clear the output in the console.

print(logo)

auction = {} # key --> name, value --> bid

# Loop while there are more bidding
while True:
  name = input("What is your name?: ")
  bid = int(input("What is your bid?: $"))
  auction[name] = bid

  more_people = input("Are there any other bidders? Type 'yes' or 'no'.\n")
  if more_people == "no":
    break
  clear()

# Find max bid and bidder
auction_keys = list(auction.keys())
auction_values = list(auction.values())
max_bid = max(auction_values)
max_bidder = auction_keys[auction_values.index(max_bid)]

print(f"The winner is {max_bidder} with a bid of ${max_bid}")