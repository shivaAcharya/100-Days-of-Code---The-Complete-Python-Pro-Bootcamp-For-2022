############### Blackjack Project #####################



############### Our Blackjack House Rules #####################

## The deck is unlimited in size. 
## There are no jokers. 
## The Jack/Queen/King all count as 10.
## The the Ace can count as 11 or 1.
## Use the following list as the deck of cards:
## cards = [11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]
## The cards in the list have equal probability of being drawn.
## Cards are not removed from the deck as they are drawn.
## The computer is the dealer.


from replit import clear
from art import logo
import random

cards = [11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]

# Ask user if they want to play blackjack

wannaPlay = input("Do you want to play a game of Blackjack? Type 'y' or 'n': ")
startGame = True

if wannaPlay == 'n': startGame = False


while startGame:
  clear()
  print(logo)

  # Lists for user and computer hand
  userHand, compHand = [], []
  
  # Randomly pick two cards for user
  userHand.append(random.choice(cards))
  userHand.append(random.choice(cards))
  
  # Randomly pick one computer's card
  compHand.append(random.choice(cards))
  compHand.append(random.choice(cards))
  
  def result(player, dealer, playerHand, dealerHand):
    """
    Function to display result provide player's and dealer's score
    """
    print(f"  Your final hand: {userHand}, final score: {player}")
    print(f"  Computer's final hand: {compHand}, final score: {dealer}")
    if player > 21:
      print("You went over. You lose 😭")
    elif len(playerHand) == 2 and player == 21:  
      print("You have blackjack. You won 😃")
    elif len(compHand) == 2 and dealer == 21:
      print("Computer has blackjack. You lose 😤")
    elif player == dealer:
      print("It's a draw.")
    elif dealer > 21 or player > dealer:
      print("You win 😃")
    elif player < dealer:
      print("You lose 😤")

  userScore = sum(userHand)
  compScore = sum(compHand)

  if userScore == 21 or compScore == 21:
    result(userScore, compScore, userHand, compHand)

  def display():
    print(f"  Your cards: {userHand}, current score: {userScore}")
    print(f"  Computer's first card: {compHand[0]}")

  newGame = True
  # User's play
  while newGame and userScore < 21:
    display()
    hit = input("Type 'y' to get another card, type 'n' to pass: ")
    if hit == 'n':
      newGame = False
      break
    userHand.append(random.choice(cards))
    userScore = sum(userHand)
    if 11 in userHand and userScore > 21:
      userHand.remove(11)
      userHand.append(1)
      userScore = sum(userHand)

  # Computer's play
  while compScore < 17:
    compHand.append(random.choice(cards))
    compScore = sum(compHand)
    if 11 in compHand and compScore > 21:
      compHand.remove(11)
      compHand.append(1)
  
  # Print Result
  result(userScore, compScore, userHand, compHand)

  wannaPlay = input("Do you want to play a game of Blackjack? Type 'y' or 'n': ")

  if wannaPlay == "n":
    startGame = False
    break
  
print("Game Over.")